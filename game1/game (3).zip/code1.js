gdjs.Game_32OverCode = {};
gdjs.Game_32OverCode.localVariables = [];


gdjs.Game_32OverCode.eventsList0 = function(runtimeScene) {

};

gdjs.Game_32OverCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.Game_32OverCode.eventsList0(runtimeScene);


return;

}

gdjs['Game_32OverCode'] = gdjs.Game_32OverCode;
